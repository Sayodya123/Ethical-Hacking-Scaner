# GUIDE — Getting started (Safe setup)

## Goals
This small toolkit demonstrates:
- How to check open TCP ports (local-only) programmatically.
- How to attempt a banner read from a service (in a safe, limited way).
- How to structure an educational repo for ethical hacking students.

## Safety-first behavior
- By default the scanner **only** targets localhost (127.0.0.1).
- To run against other IPs you must set an environment variable: `ALLOW_REMOTE=1`.
  This is intentionally required so you consciously enable remote tests and accept responsibility.

## Requirements
- Python 3.8+
- Run in an isolated lab/VM when experimenting.

## Quick start (Linux/Mac)
1. Unzip the archive and `cd` into the folder.
2. Inspect files: `less ABOUT.txt`, `less GUIDE.md`
3. To run the safe localhost scan:
```bash
python3 tool/safe_scan.py
```
This will scan ports 20-1024 on 127.0.0.1 by default.

## To allow remote targets (ONLY when you have explicit permission)
1. Edit `labs/targets.txt` and add the authorized target IPs (one per line).
2. Export environment var and run:
```bash
export ALLOW_REMOTE=1
python3 tool/safe_scan.py --targets labs/targets.txt --min-port 1 --max-port 1024
```
You will be shown a confirmation prompt before any remote connections are attempted.

## Notes for instructors
- Keep `solutions/` or instructor-only files in a private branch.
- Use isolated VMs (e.g., VirtualBox) for exercises.
- Consider network segmentation to avoid accidental scans of the LAN.

