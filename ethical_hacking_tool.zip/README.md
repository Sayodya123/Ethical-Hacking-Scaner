# Ethical Hacking Learning Toolkit (Safe)

**Purpose:** Educational toolkit for ethical-hacking students.  
**Author:** Sayodya hasaranga

This repository is intentionally safe by default. It contains a small learning script that demonstrates basic port-checking and banner-reading techniques *only against localhost* (127.0.0.1). Remote scanning is blocked unless you explicitly opt in (see GUIDE.md).

**IMPORTANT — Usage & Legal**
- Use this toolkit only on systems you own or have explicit authorization to test.
- Do not run against production or third-party systems without permission.
- This repository is for educational and defensive purposes.

Contents:
- `tool/safe_scan.py` — Python script (safe defaults).
- `labs/targets.txt` — default target list (127.0.0.1).
- `GUIDE.md` — how to use and how to run safe labs.
- `ABOUT.txt` — author & file metadata.
- `files/file_details.txt` — example file metadata for exercises.

License: MIT (see LICENSE file).
