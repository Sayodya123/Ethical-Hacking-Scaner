
#!/usr/bin/env python3


# safe_scan.py
# Educational, safe port-checker and banner reader.
# Default target: localhost (127.0.0.1).
# To enable remote targets you must set environment variable ALLOW_REMOTE=1.

import socket
import argparse
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import sleep

DEFAULT_MIN_PORT = 20
DEFAULT_MAX_PORT = 1024
DEFAULT_TIMEOUT = 1.0  # seconds
LOCAL_ONLY = {"127.0.0.1", "localhost", "0.0.0.0"}

def is_local_target(host):
    try:
        # Resolve host to IP(s) and check if any are local
        infos = socket.getaddrinfo(host, None)
        for info in infos:
            addr = info[4][0]
            if addr.startswith("127.") or addr == "::1":
                return True
        # allow if hostname is 'localhost'
        if host in LOCAL_ONLY:
            return True
    except Exception:
        pass
    return False

def check_port(host, port, timeout=DEFAULT_TIMEOUT):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        try:
            # attempt a small banner read (non-blocking / low timeout)
            s.settimeout(0.6)
            banner = b""
            try:
                banner = s.recv(1024)
            except Exception:
                banner = b""
            return (port, True, banner.decode(errors="replace").strip())
        finally:
            s.close()
    except Exception:
        try:
            s.close()
        except Exception:
            pass
        return (port, False, "")

def scan_host(host, ports, workers=64):
    results = []
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(check_port, host, p): p for p in ports}
        for fut in as_completed(futs):
            results.append(fut.result())
    return sorted(results, key=lambda x: x[0])

def confirm_remote_action(targets):
    print("WARNING: You are about to attempt network connections to remote targets:")
    for t in targets:
        print("  -", t)
    resp = input("Type 'I_HAVE_PERMISSION' to continue: ").strip()
    return resp == "I_HAVE_PERMISSION"

def load_targets_from_file(path):
    with open(path, "r") as f:
        lines = [line.strip() for line in f if line.strip() and not line.strip().startswith("#")]
    return lines

def main():
    parser = argparse.ArgumentParser(description="Safe, educational local-only port checker.")
    parser.add_argument("--targets", "-t", help="Comma-separated hosts or path to file with hosts (one per line). Default: 127.0.0.1", default="127.0.0.1")
    parser.add_argument("--min-port", type=int, default=DEFAULT_MIN_PORT)
    parser.add_argument("--max-port", type=int, default=DEFAULT_MAX_PORT)
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    parser.add_argument("--workers", type=int, default=64)
    args = parser.parse_args()

    # Determine list of targets
    targets = []
    if os.path.exists(args.targets):
        targets = load_targets_from_file(args.targets)
    else:
        targets = [t.strip() for t in args.targets.split(",") if t.strip()]

    # Safety check: if any target is non-local, require explicit env var and confirmation
    nonlocal_targets = [t for t in targets if not is_local_target(t)]
    if nonlocal_targets:
        if os.environ.get("ALLOW_REMOTE") != "1":
            print("ERROR: Remote targets detected but ALLOW_REMOTE is not set. Aborting.")
            print("To allow remote targets, set environment variable ALLOW_REMOTE=1 AND run again.")
            sys.exit(2)
        else:
            # double confirmation
            ok = confirm_remote_action(nonlocal_targets)
            if not ok:
                print("Aborted by user.")
                sys.exit(3)

    ports = list(range(max(1, args.min_port), min(65535, args.max_port) + 1))
    for target in targets:
        print(f"Scanning {target} ports {args.min_port}-{args.max_port} (safe mode)...")
        results = scan_host(target, ports, workers=args.workers)
        open_ports = [r for r in results if r[1]]
        if open_ports:
            print(f"Found {len(open_ports)} open ports on {target}:")
            for p, _, banner in open_ports:
                line = f"  - Port {p} open"
                if banner:
                    line += f" | Banner: {banner[:200]}"
                print(line)
        else:
            print(f"No open ports found in the scanned range on {target}.")
        # polite pause between targets
        sleep(0.2)

if __name__ == "__main__":
    main()
